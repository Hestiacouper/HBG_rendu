﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Enemy : MonoBehaviour
{

    public const int enemyMaxHealth = 10;
    public int enemyCurrentHealth = enemyMaxHealth;
    public Vector2 enemyPosition;
    public GameObject FireThings;
     

    // Use this for initialization
    void Start()
    {



    }

    // Update is called once per frame
    void Update()
    {
        enemyPosition = transform.position;
    }


    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Weapons")
        {

            enemyCurrentHealth -= BatlleAxe.batlleAxeDamages;
            Destroy(coll.gameObject);
            if (enemyCurrentHealth <= 0)
            {
                Destroy(gameObject);
                Instantiate(FireThings, enemyPosition, Quaternion.identity);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D coll)
    {
        if (coll.gameObject.tag == "Spells")
        {
            Destroy(gameObject);
            Instantiate(FireThings, enemyPosition, Quaternion.identity);
        }
}
}