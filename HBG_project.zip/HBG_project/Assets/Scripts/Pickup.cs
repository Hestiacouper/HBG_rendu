﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : MonoBehaviour
{

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Weapons")
        {
            GetComponent<PlayerStats>().playerDamages += BatlleAxe.batlleAxeDamages;
            GetComponent<Inventory>().playerAxes += 1;
            Destroy(collision.gameObject);   
        }

        else if (collision.gameObject.tag == "Keys")
        {
            GetComponent<Inventory>().playerKeys += 1;
            Destroy(collision.gameObject);
        }

        else if (collision.gameObject.tag == "FireThings")
        {
            GetComponent<Inventory>().playerFireThing += 1;
            GetComponent<PlayerStats>().playerSickness += 1;
            Destroy(collision.gameObject);
        }
    }
}