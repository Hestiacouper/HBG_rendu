﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnnemyFollow : MonoBehaviour
{
    [SerializeField]
    private float speed;
    [SerializeField]
    private float stopMooving;
    [SerializeField]
    private float detectionRange;
    private Transform target;
    
    
	// Use this for initialization
	void Start ()
	{
	    target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
	    GetComponent<AudioSource>().Play();

	} 
	
	// Update is called once per frame
    void Update()
    {
        GetComponent<AudioSource>().Pause();
        float step = speed * Time.deltaTime;
        if (Vector2.Distance(transform.position, target.position) < detectionRange)
        {
            if (Vector2.Distance(transform.position, target.position) >= stopMooving)
            {
                transform.position = Vector2.MoveTowards(transform.position, target.position, step);
                GetComponent<AudioSource>().UnPause();
            }
            else
            {
                GetComponent<AudioSource>().Pause();
            }
        }
    }
}
