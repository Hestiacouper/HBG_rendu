﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollowPlayer : MonoBehaviour {

    public GameObject Player;       
    private Vector3 offset;         

    //Simple code to make the camera follow the player

    void Start()
    {
        
        offset = transform.position - Player.transform.position;

    }

   
    void Update()
    {
        
        transform.position = Player.transform.position + offset;

    }
}

