﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenDoor : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Door")
        {
            if (GetComponent<Inventory>().playerKeys > 0)
            {
                GetComponent<Inventory>().playerKeys -= 1;
                Destroy(coll.gameObject);
            }
        }
    }
}
