﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Boss : MonoBehaviour
{
    [SerializeField]
    private const int BossMaxHealth = 100;
    
    public int bossCurrentHealth = BossMaxHealth;

    public string oldGameScene;

    public string winScreen;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    //Damage the boss and load win screen when boss killed
    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Weapons")
        {

            bossCurrentHealth -= BatlleAxe.batlleAxeDamages;
            Destroy(coll.gameObject);
            if (bossCurrentHealth <= 0)
            {
                Destroy(gameObject);
                //SceneManager.UnloadSceneAsync(oldGameScene);
                SceneManager.LoadScene(winScreen);
            }
	    }

    }

	void OnTriggerEnter2D(Collider2D coll)
	{
		if (coll.gameObject.tag == "Spells")
		{
			bossCurrentHealth -= 10;
			if (bossCurrentHealth <= 0)
			{
				Destroy(gameObject);
				SceneManager.LoadScene(winScreen);
			}
		}
	}
}
