﻿using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerStats : MonoBehaviour
{

    public const int ManaMax = 20;
    public int currentMana = ManaMax;
    public string newGameScene;
    public int playerDamages = 0;
    public const int playerHealth = 20;
    public int currentHealth = playerHealth;
    public int playerSickness = 0;
    [SerializeField]
    private Slider healthBar;
    [SerializeField]
    private Slider sicknessBar;
    
    

    public const int playerMaxSickness = 5;
    // Use this for initialization
    void Start () {
	    InvokeRepeating("ManaRegeneration", 2.0f, 5.0f);
        healthBar.value = currentHealth;
        sicknessBar.value = playerSickness;
    }
	
	// Update is called once per frame
	void Update () {
	    if (playerSickness > playerMaxSickness)
	    {
	        SceneManager.LoadScene(newGameScene);

	    }

	    healthBar.value = currentHealth;
	    sicknessBar.value = playerSickness;

	}

    

    void OnCollisionEnter2D(Collision2D coll)
    {
        if (coll.gameObject.tag == "Enemy" || coll.gameObject.tag=="Boss")
        {

            currentHealth -= 1;
            
            if (GetComponent<PlayerStats>().currentHealth <= 0)
            {
                SceneManager.LoadScene(newGameScene);
                
            }
        }
    }

    public void ManaRegeneration()
    {
        if (currentMana < ManaMax)
            currentMana += 1;
    }
}
