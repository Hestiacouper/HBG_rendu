﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSounds : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
	    
        
	}
	
	// Update is called once per frame
	void Update ()
	{
       
	    if (GetComponent<Player>().isWalking)
	    {
	        GetComponent<AudioSource>().UnPause();
        }
	    GetComponent<AudioSource>().Pause();
    }
}
