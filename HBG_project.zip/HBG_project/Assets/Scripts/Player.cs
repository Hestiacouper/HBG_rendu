﻿using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using UnityEngine;
using TMPro;
using UnityEngine.Experimental.UIElements;

public class Player : MonoBehaviour
{

    [SerializeField] float speed = 10;
    Rigidbody2D myRigidbody2D;

    private Vector2 axePosition;
    private Vector2 spellPosition;
    [SerializeField]
    private GameObject ThrowAxeRight, ThrowAxeLeft, ThrowAxeUp, ThrowAxeDown;
    [SerializeField]
    private GameObject ExplosionSpell;
    [SerializeField]
    private float throwRate = 0.5f;
    [SerializeField]
    private float nextThrow = 0;
    private bool up, right, left, down;
    public bool isWalking = false;
    [SerializeField] 
    private Animator animator;
    void Start()
    {

        myRigidbody2D = GetComponent<Rigidbody2D>();
        GetComponent<AudioSource>().Pause();


    }


    void Update()
    {


        float verticalMove = Input.GetAxis("Vertical");       
        myRigidbody2D.velocity = new Vector2(speed * verticalMove, myRigidbody2D.velocity.y);
        
        float horizontalMove = Input.GetAxis("Horizontal");

        myRigidbody2D.velocity = new Vector2(speed * horizontalMove, myRigidbody2D.velocity.x);
        if (verticalMove != 0 || horizontalMove != 0)
        {
            GetComponent<AudioSource>().UnPause();
            isWalking = true;
        }

        else
        {
            GetComponent<AudioSource>().Pause();
            isWalking = false;
        }
            
            
        if (verticalMove < 0)
        {
            down = true;
            up = left = right = false;
        }
        else if (verticalMove > 0)
        {
            up = true;
            down = left = right = false;
        }
        else if (horizontalMove < 0)
        {
            left = true;
            down = up = right = false;
        }
        else if (horizontalMove > 0)
        {
            right = true;
            down = up = left = false;
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        if (Input.GetButtonDown("Fire1") && Time.time > nextThrow)
        {
            nextThrow = Time.time + throwRate;
            if (GetComponent<Inventory>().playerAxes > 0)
            {
                Throw();
            }
            
        }

        if (Input.GetButtonDown("Fire2") && GetComponent<PlayerStats>().currentMana == 20)
        {
            if (GetComponent<Inventory>().playerFireThing > 3)
            {
                CastExplosion();
            }
            
        }
        
        animator.SetBool("right", right);
        animator.SetBool("left",left);
        animator.SetBool("up", up);
        animator.SetBool("down", down);
        animator.SetBool("walking", isWalking);
    }

    public void Throw()
    {
        axePosition = transform.position;
        if (right)
        {
            axePosition += new Vector2(+1f, 0f);
            Instantiate(ThrowAxeRight, axePosition, Quaternion.identity);
        }

        else if (left)
        {
            axePosition += new Vector2(-1f, 0f);
            Instantiate(ThrowAxeLeft, axePosition, Quaternion.identity);
        }
        else if (up)
        {
            axePosition += new Vector2(0f, +1f);
            Instantiate(ThrowAxeUp, axePosition, Quaternion.identity);
        }
        else if (down)
        {
            axePosition += new Vector2(0f, -1f);
            Instantiate(ThrowAxeDown, axePosition, Quaternion.identity);
        }
    }

    public void CastExplosion()
    {
        spellPosition = transform.position;

        Instantiate(ExplosionSpell, spellPosition, Quaternion.identity);
    }
}


