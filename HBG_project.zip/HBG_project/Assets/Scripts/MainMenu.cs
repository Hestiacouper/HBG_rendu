﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Debug = UnityEngine.Debug;

public class MainMenu : MonoBehaviour
{

    public Button newGameButton;

    public Button OptionButton;

    public Button ExitButton;

    public string newGameScene;

    public string oldGameScene;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void NewGame()
    {
        SceneManager.LoadScene(newGameScene);
        //SceneManager.UnloadSceneAsync(oldGameScene);
    }

    public void Option()
    {

    }

    public void Exit()
    {
        Debug.Log("quit");
        Application.Quit();
    }

}
