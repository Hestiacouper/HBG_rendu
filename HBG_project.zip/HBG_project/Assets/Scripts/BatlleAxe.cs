﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BatlleAxe : MonoBehaviour
{
    //Battle Axe Stats
    public Vector2 axePosition;
    public const int batlleAxeDamages = 5;
    public float speedX = 5f;
    public float speedY = 0f;
    Rigidbody2D myRigidbody2D;

	// Use this for initialization
	void Start ()
	{
         
	    myRigidbody2D = GetComponent<Rigidbody2D>();
	    axePosition = transform.position;
	}
	
	// Update is called once per frame
	void Update () { 
        //Destroy ballteAxe once throwed
        myRigidbody2D.velocity = new Vector2(speedX, speedY);
        Destroy(gameObject, 3f);

	}

    
    
  
     
    
}
